// Created August 16th, 2023 - By: Devon Griffith A.K.A. rootPHAGE / 我爱数据
// Run on Windows [ Node <path to file>\XSS_via_Third-Party_Integrations_JavaScript.js ]
// XSS via Third-Party Integrations = 3rd-Party content gets loaded nito the browser from an
// embedded iFrame linked to the evil site with more malware

<iframe src="https://evil.com/xss"></iframe>

// DO NOT USE THIS SCRIPT MALICIOUSLY - PROVIDED FOR EDUCATIONAL PURPOSES ONLY
