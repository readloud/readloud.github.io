```
GEMFILE:
gem 'chunky_png', '~> 1.3', '>= 1.3.5'
=
INSTALL:
gem install chunky_png -v 1.3.5
```
