# Minimal WSL2 systemd script

This is a simple script to perform a minimal installation of @diddledan's `one-script-wsl2-systemd` for Insiders.

This script only includes the following:
- add `systemd` support
- add classic snap support

The script should be running as root. 

That's it.
